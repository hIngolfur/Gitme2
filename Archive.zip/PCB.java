public class PCB {
    public int processID;
    private String processState;
    private int programCounter;
    // ... other PCB attributes

    public PCB(int processID) {
        this.processID = processID;
        this.processState = "Ready"; // Initial state
        this.programCounter = 0;
        // ... initialize other attributes
    }

    // Getters and setters for attributes
    public int getProcessID() {
        return processID;
    }

    public void setProcessState(String processState) {
        this.processState = processState;
    }

    public String getProcessState() {
        return processState;
    }

    // ... other PCB methods (e.g., for resource management, I/O operations)
  
}