# Install Java 11
apt-get -y install openjdk-11-jdk
