/******************************************************************************
 *  Nafn    : Ebba Þóra Hvannberg
 *  T-póstur: ebba@hi.is
 *
 *  Lýsing  : prentar út útkomuna úr 3*4+5
 *
 *
 *****************************************************************************/


public class Utreikningur {
    public static void main(String[] args) {
        System.out.println(3 * 4 + 5);
    }
}
