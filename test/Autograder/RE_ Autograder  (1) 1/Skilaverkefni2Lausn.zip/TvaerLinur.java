/******************************************************************************
 *  Nafn    : Ebba Þóra Hvannberg
 *  T-póstur: ebba@hi.is
 *
 *  Lýsing  : prentar út tvær línur af texta
 *
 *
 *****************************************************************************/


public class TvaerLinur {
    public static void main(String[] args) {
        System.out.println("Fyrsta vikan í skólanum var skemmtileg");
        System.out.println("Ég gat klárað þetta verkefni");
    }
}
